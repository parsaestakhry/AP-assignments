package contacts;

public class Contact {
    int id;
    String firstName, lastName, telNo,groupName;

    @Override
    public String toString() {
        return "id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", telNo=" + telNo + ", groupName=" + groupName;
    }



}
